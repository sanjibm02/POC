﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using NumberToWords;
using System.Text;

namespace NToWUnitTestProject
{
    [TestClass]
    public class UnitTest1
    {
        NumberToWordConversion numberObj = new NumberToWordConversion();
        [TestMethod]
        public void TestMethodHundred_NumberToWord()
        {
            string input ="134";
            string expectedoutput = "The number in currency format is:One Hundred Thirty Four ";
            StringBuilder actualOutput = numberObj.DisplayOutput(input);
            Assert.AreEqual(expectedoutput, actualOutput.ToString());
        }
        [TestMethod]
        public void TestMethodThousand_NumberToWord()
        {
            string input = "13456";
            string expectedoutput = "The number in currency format is:Thirteen Thousand Four Hundred Fifty Six ";
            StringBuilder actualOutput = numberObj.DisplayOutput(input);
            Assert.AreEqual(expectedoutput, actualOutput.ToString());
        }
        [TestMethod]
        public void TestMethodMillion_NumberToWord()
        {
            string input = "1113456";
            string expectedoutput = "The number in currency format is:One Million One Hundred Thirteen Thousand Four Hundred Fifty Six ";
            StringBuilder actualOutput = numberObj.DisplayOutput(input);
            Assert.AreEqual(expectedoutput, actualOutput.ToString());
        }

        [TestMethod]
        public void TestMethodDoubleMillion_NumberToWord()
        {
            string input = "11113456";
            string expectedoutput = "The number in currency format is:Eleven Million One Hundred Thirteen Thousand Four Hundred Fifty Six ";
            StringBuilder actualOutput = numberObj.DisplayOutput(input);
            Assert.AreEqual(expectedoutput, actualOutput.ToString());
        }
        [TestMethod]
        public void TestMethodBillion_NumberToWord()
        {
            string input = "2211113456";
            string expectedoutput = "The number in currency format is:Two Billion Two Hundred Eleven Million One Hundred Thirteen Thousand Four Hundred Fifty Six ";                                    
            StringBuilder actualOutput = numberObj.DisplayOutput(input);
            Assert.AreEqual(expectedoutput, actualOutput.ToString());
        }
        [TestMethod]
        public void TestMethodValidDoubleInput_NumberToWord()
        {
            string input = "sanib";
            string expectedoutput = "Please enter valid number";
            StringBuilder actualOutput = numberObj.DisplayOutput(input);
            Assert.AreEqual(expectedoutput, actualOutput.ToString());
        }
        [TestMethod]
        public void TestMethodValidWholeNumber_NumberToWord()
        {
            string input = "123.45";
            string expectedoutput = "";
            StringBuilder actualOutput = numberObj.DisplayOutput(input);
            Assert.AreEqual(expectedoutput, actualOutput.ToString());
        }
    }
}
